
public class Parent {
	private Adult self;
	private Adult partner;
	
	
}
