/**
 * To support the functionality of adding and remove classmates from classes.
 * @author Ken
 *
 */
public interface Classmate {
	public void makeClassmate(Person person) throws Exception;
	public void removeClassmate(Person person) throws Exception;
}
