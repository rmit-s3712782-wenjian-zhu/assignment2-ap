
public class NotToBeClassMatesException extends Exception{
	
	NotToBeClassMatesException(String name) {
	      super(name + "is too young to be at school.");
	   } 
	
}
