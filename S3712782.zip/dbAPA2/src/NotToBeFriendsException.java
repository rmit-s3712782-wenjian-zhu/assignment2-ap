
public class NotToBeFriendsException extends Exception{
	
	NotToBeFriendsException() {
		super("A adult and a child cannot be friends or two children \nwith age gap cannot be friends.");
	}
}
