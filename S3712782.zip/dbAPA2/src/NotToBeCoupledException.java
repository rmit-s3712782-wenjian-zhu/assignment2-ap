
public class NotToBeCoupledException  extends Exception{
	
	NotToBeCoupledException(String name) {
		super(name + " need to be a adult");
	}

}
