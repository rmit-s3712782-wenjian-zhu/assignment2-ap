import java.util.ArrayList;
import java.util.List;
/**
 * Adult is a subclass which extends Person.
 */
public class Adult extends Person implements Classmate, Colleague{
	//private Parent isParent;
	private Adult partner;
	private ArrayList<Dependent> children = new ArrayList<>();
	private ArrayList<Adult> colleagues = new ArrayList<>();
	private ArrayList<Person> classmates = new ArrayList<>();
	
	/**
	 * @param name 
	 * @param age
	 * @param status
	 * @param photo
	 * @param gender
	 * @param state
	 * @throws NoSuchAgeException
	 */
	public Adult(String name, String photo, String status, char gender, int age, String state) {
	    super(name, photo, status, gender, age, state);
	}
	
	public void delete(Person p) {
		super.delete(p);
		if(p instanceof Adult) {
			removeClassmate(p);
			removeColleague(p);
			removePartner(p);
		}
		else if(p instanceof Child) {
			removeChild(p);
			removeClassmate(p);
		}
		else {
			removeChild(p);
		}
	}

	public void marryTo(Person p) {
		try {
			if(p instanceof Adult) {
				if(((Adult) p).getPartner() == null && getPartner() == null) {
					setPartner((Adult) p);
					((Adult) p).setPartner(this);
					System.out.println(getName() + " and " + p.getName() + " become couple");}
				else if(((Adult) p).getPartner() != null || getPartner() != null)
					throw new NotAvailableException("one of member has been in a relationship");
				}
			else throw new NotToBeCoupledException(p.getName());
			}
		catch(NotToBeCoupledException e) {
			System.out.printf("%s can not add %s as a partner becasue %s\n",
					getName(), p.getName(), e.getMessage());
		}
		catch(NotAvailableException e) {
			System.out.printf("%s can not add %s as a partner becasue %s\n",
					getName(), p.getName(), e.getMessage());
		}
	}
	
	@Override
	public void makeFriend(Person p) {
	try {
		if(p instanceof YoungChild) throw new TooYoungException();
		else if(p instanceof Child) throw new NotToBeFriendsException();
		else {
			addFriend(p);
			p.addFriend(this);
			}
		}
		catch(TooYoungException e) {
			System.out.println(e.getMessage());
			System.out.println(getName() + " and " + p.getName() + " cannot be friends");
			}
		catch(NotToBeFriendsException e) {
			System.out.println(e.getMessage());
			System.out.println(getName() + " and " + p.getName() + " cannot be friends");
			}
		}
	
	@Override
	public void makeClassmate(Person p) {
		try {
			if(p instanceof YoungChild) throw new NotToBeClassMatesException(p.getName());
			else {
				addClassmate(p);
				if (p instanceof Adult) {
					((Adult) p).addClassmate(this);
					}
					else ((Child) p).addClassmate(this);
			}
		}
		catch (Exception e) {
			System.out.println(e);
			System.out.println(getName() + " and " + p.getName() + " cannot be classmates");
		}
	}
	
	@Override
	public void makeColleague(Person p) {
		try {
			if(p instanceof Dependent) throw new NotToBeColleaguesException(p.getName());
			else {
				addColleague((Adult) p);
				((Adult) p).addColleague(this);
			}
		}
		catch (Exception e) {
			System.out.println(e);
			System.out.println(getName() + " and " + p.getName() + " cannot be colleague");
		}
	}
	
	public void getChildrenName(){
		for(Dependent d: children) {
			System.out.println(d.getName());
		}
	}
	
	//Getters and setters;
	public Adult getPartner() {
		return partner;
	}
	 
	public ArrayList<Dependent> getChildren(){
		return children;
	}
	
	public ArrayList<Adult> getColleagues(){
		return colleagues;
	}
	
	
	public ArrayList<Person> getClassmates(){
		return classmates;
	}
	
	public void addChild(Dependent child) {
		children.add(child);
		System.out.println(this.getName() + " added " + child.getName() + " as child");
	}
	
	public void addClassmate(Person p) {
		classmates.add(p);
		System.out.printf("%s is now classmate with %s\n",getName(),p.getName());
	}
	
	public void addColleague(Adult a) {
		colleagues.add(a);
		System.out.printf("%s is now colleague with %s\n",getName(),a.getName());
	}
	
	public void setPartner(Person p) {
		partner = (Adult) p;
	}
	
	@Override
	public String getType() {
		return "Adult";
	}
	
	/**
	 * Remove classmate relation if there is a classmate with same name
	 * @param p
	 */
	public void removeClassmate(Person p){
		for(Person p2: getClassmates()) {
			if(p2.getName() == p.getName()) {
				getClassmates().remove(p2);
				System.out.printf("%s is no longer classmate with %s\n",getName(),p.getName());
			}
		}//end for
	}//end method
	
	/**
	 * Remove classmate relation if there is a classmate with same name
	 * @param p
	 */
	public void removeColleague(Person p){
		for(Person p2: getClassmates()) {
			if(p2.getName() == p.getName()) {
				getClassmates().remove(p2);
				System.out.printf("%s is no longer colleague with %s\n",getName(),p.getName());
			}
		}//end for
	}//end method
	
	/**
	 * Remove child if there is a classmate with same name
	 * @param p
	 */
	public void removeChild(Person p) {
		try {
			for(Person p2: getChildren()) {
			if(p2.getName() == p.getName()) {
				getChildren().remove(p2);
				System.out.printf("%s is no longer %s's parent\n",getName(),p.getName());
			}
		}
			} catch (Exception e) {
				System.out.println(e.getMessage());
				}
		}
	
	public void removePartner(Person p) {
		if(p instanceof Adult) {
			if(((Adult) p).getPartner() == this) {
				setPartner(null);
				System.out.printf("%s is no longer %s's partner\n",getName(),p.getName());
			}
		}
	}
	
	@Override
	public void deleteSelf() {
		try {
			if(getChildren().size() == 0) {
				for(Person p: getClassmates()) {
					p.delete(p);
					}
				for(Person p: getColleagues()) {
					p.delete(p);
					}
				for(Person p: getFriends()) {
					p.delete(p);
				}
			System.out.println(this.getName() + " has succesfully been deleted from MiniNet");
				}
			else throw new NoParentException("Dependents need to have parent to be in MiniNet");
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}
	
	public boolean checkClassmate(Person a) {
		for(Person p: getClassmates()) {
			if (p.getName().equals(a.getName())) {
					System.out.println(getName() + " and " + a.getName() + " are classmates");
				return true;
			}
		}
		return false;
	}
	

	public boolean checkColleague(Adult a) {
		for(Person p: getColleagues()) {
			if (p.getName().equals(a.getName())) {
					System.out.println(getName() + " and " + a.getName() + " are colleague");
				return true;
			}
		}
		return false;
	}
	
	
	public boolean checkChild(Dependent d) {
		for(Dependent dependent: getChildren()) {
			if (dependent.getName().equals(d.getName())) {
				System.out.println(getName() + " is " + d.getName() + "'s parent");
			return true;
		}
		}
		return false;
	}
	
	
	public String checkRelation(Person p) {
		String s = "";
		if(checkFriendship(p)) s += "friend, ";
		if(p instanceof Adult) {
			if(checkColleague((Adult) p)) s += "colleague, ";
			if(checkClassmate((Adult) p)) s += "classmate, ";
			if(getPartner() == p)
				s += "couple, ";
		}
		else if(p instanceof Child) {
			if(checkChild((Child) p)) s += "parent, ";
			if(checkClassmate((Child) p)) s += "classmate, ";
		}
		else if(checkChild((YoungChild) p)) s += "parent, ";
		if (s.equals("")) {
			s = "No direct relation.";
		}
		else {
			s = s.substring(0, s.length() - 2);
		}
		if(this.getName().equals(p.getName())) s = "Self";
		return s;
	} 
	
	public void makeParent(Dependent d) {
		try {
			if(getPartner() == null) throw new NoParentException("Parents need to be in relationship first");
			addChild(d);
		}
		catch(NoParentException e) {
			System.out.println(e.getMessage());
		}
	}

}//end class
