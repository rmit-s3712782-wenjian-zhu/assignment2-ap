
public class NotToBeColleaguesException extends Exception {

   NotToBeColleaguesException(String name) {
      super(name + " is too young to work");
   }

}