/**
 * 
 * @author Ken
 *
 */
public class NoSuchAgeException extends Exception{
	
	/**
	 * This is an exception when negative or over 150 was inputed as age.
	 * @param errmsg Takes error message to call superclass's constructor.
	 * @param age The exception age which was caught.
	 */
	public NoSuchAgeException(String errmsg, int age) {
		super(errmsg);
		System.out.println("There is no much age as " + age);
	}//end NoSuchAgeException
}
