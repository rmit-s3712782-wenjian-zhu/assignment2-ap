/**
 * YoungChild is a subclass of person who 
 * are the users who age from 2 years old 
 * or younger.
 */
public class YoungChild extends Dependent{
	
	/**
	 * @param name 
	 * @param age
	 * @param status
	 * @param photo
	 * @param gender
	 * @param state
	 * @throws NoSuchAgeException
	 */
	YoungChild(String name, String photo, String status, char gender, int age, String state) {
	    super(name, photo, status, gender, age, state);
	    /*
		setParent1(p1);
		setParent2(p2);
		p1.addChild(this);
		p2.addChild(this);
		*/
	}
	
	public String getType() {
		return "YoungChild";
	}

	
	@Override
	public void makeFriend(Person p) {
		try {
			if (p instanceof Adult) throw new NotToBeFriendsException();
			else if (sameFamily((Dependent) p)) {
				this.addFriend(p);
				p.addFriend(this);
			}
			else throw new TooYoungException();
		}
		catch(Exception e) {
			System.out.println(e.getMessage());
			System.out.println(getName() + " and " + p.getName() + " cannot be friends ");
			}
	}
	

	@Override
	public void deleteSelf() {
		for(Person p: this.getFriends()) {
			p.delete(this);
		}
		getParent1().removeChild(this);
		getParent2().removeChild(this);
		System.out.println(this.getName() + " has succesfully been deleted from MiniNet");
	}
	
	@Override
	public void delete(Person p) {
		deleteFriend(p);
	}


	
	@Override
	public String checkRelation(Person p) {
		if(p instanceof Adult) {
			return p.checkRelation(this);
		}
		else if (p instanceof Child) {
			return p.checkRelation(this);
		}
		else {
		String s = "";
		if (s.equals("")) {
			s = "No direct relation.";
		}
		else {
			s = s.substring(0, s.length() - 2);
		}
		if(this.getName().equals(p.getName())) s = "Self";
		return s;
		}
	}
	
	
	
}
