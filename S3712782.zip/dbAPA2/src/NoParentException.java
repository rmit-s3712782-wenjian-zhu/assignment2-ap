
public class NoParentException extends Exception{
	
	/**
	 * This is an exception when a child or young child has no parent or
	 * has only one parent, e.g adding a child to one adult, or to two adults 
	 * who are not a couple. That also happens when trying to delete an adult 
	 * who has at least one dependent.
	 * @param errmsg Takes error message to call superclass's constructor.
	 * @param age The exception age which was caught.
	 */
	NoParentException(String errmsg) {
		super(errmsg);
	}
}//end NoParentException.