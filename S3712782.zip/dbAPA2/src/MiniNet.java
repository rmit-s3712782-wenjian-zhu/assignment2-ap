import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;
import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;
/**
 * MiniNet 2.0
 * <p> MiniNet is the main startup class. </p>
 * 
 * @version 	2.0
 * @author 	Ken (Wenjian Zhu, S3712782)
 */
public class MiniNet extends Application {
	
	private ObservableList<Person> People =FXCollections.observableArrayList ();
	private ArrayList<Person> register = new ArrayList<>();
	public Stage primaryStage;
	private mainViewController controller;
	
	
	public MiniNet() throws Exception{
		loadPeopleInfo();
		loadRelationInfo();
		validateRegister();
	}
	
	
	@Override
	public void start(Stage primaryStage)  {
		this.primaryStage = primaryStage;
		primaryStage.setResizable(false);
		displayMainInterface();
	}
	
	
	/**
	 * This is the main method of MiniNet.
	 * 
	 * @throws NoSUchAgeException
	 */
	public static void main(String [] args) {
		launch(args);
		//Driver MiniNet = new Driver() {};
		//MiniNet.addData();
		//MiniNet.mainMenu();
	}//end main
	
	
	/**
	* Show the main view.
	*/
	public void displayMainInterface() {
		try {
			FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("MainView.fxml"));
	        Scene scene = new Scene(fxmlLoader.load());
	        primaryStage.setTitle("MiniNet 2.0");
	        primaryStage.setScene(scene);
	        primaryStage.show(); 
	        controller = fxmlLoader.getController();
	        controller.setModel(this);
	        } catch (IOException e) {
	        	e.printStackTrace();
	        	}
		}
	
	
	public void loadPeopleInfo() {
		Scanner input = null;
		String line = null;
	    File file = new File("people.txt");
	    try {
	    	input = new Scanner(new FileInputStream(file));
	    	} catch (FileNotFoundException e) {
	    		System.err.println("No Such File.");
	    		}

	  	while (input.hasNextLine()) {
	  		line = input.nextLine();
	  		String[] info = line.split(", ");
	  		addPersonByString(info);
	  		}
	  	input.close();
	}
	
	
	public void loadRelationInfo() throws Exception{
		Scanner input = null;
		String line = null;
	    File file = new File("relations.txt");
	    try {
	    	input = new Scanner(new FileInputStream(file));
	    	while (input.hasNextLine()) {
	    		Person p1 = null;
	    		Person p2 = null;
	    		line = input.nextLine();
	    		String[] info = line.split(", ");
	    		for (Person p: register) {
	    			if (p.getName().equals(info[0]))
	    				p1 = p;
	    		}
	    		for (Person p: register) {
	    			if (p.getName().equals(info[1]))
	    				p2 = p;
	    		}
	    		if (p1 ==null || p2 == null) continue;
	    		// read relation
	    		if (info[2].equals("couple")) {
	               ((Adult) p1).marryTo(p2);
	    			}
	    		else if (info[2].equals("parent")) {
	    			if (p1.getAge() > p2.getAge()) {
	    				((Adult) p1).addChild((Dependent) p2);
	    				((Dependent) p2).makeParent((Adult) p1);
	    			}
	    			else {
	    				((Adult) p2).addChild((Dependent) p1);
	                  ((Dependent) p1).makeParent((Adult) p2);
	    			}
	    		}
	            	else if (info[2].equals("friends")) {
	            		p1.addFriend(p2);
	            		p2.addFriend(p1);
	            	}
	            	else if (info[2].equals("colleagues")) {
	            		((Adult) p2).addColleague((Adult) p1);
	            		((Adult) p1).addColleague((Adult) p2);
	            	}
	            	else if (info[2].equals("classmates")) {
	            		((Adult) p2).makeClassmate(p1);
	            		((Adult) p1).makeClassmate(p2);
	            	}
	    		}
	    	} catch (FileNotFoundException e) {
	    		System.out.println("No Such File.");
	      }
	    input.close();
	   }
	
	
	public Person selectPersonByName(String name) {
		try {
			for (Person p: People) {
				if (p.getName().toUpperCase().equals(name.toUpperCase())) {
					System.out.println(p.getName() + " is selected.");
					return p;}
				}
			throw new Exception("There is no such person.");
			}
		catch(Exception e) {
			System.out.println(e.getMessage());
			}
		return null;
		}
	  
	
	public ObservableList<Person> getPeople(){
		return People;
	}
	
	
	public void addUser(Person person) {
		boolean existed = false;
		try {
			if(person instanceof Dependent) {
				if (((Dependent) person).getParent1() ==null 
						&& (((Dependent) person).getParent2()) == null)
					throw new NoParentException(person.getName() + " need to have two parents");
			}
			for(Person p:People) {
				if (p.getName() == person.getName())
					existed = true;
			}
			//if content is duplicated, throw an exception and print error message;
			if(existed) throw new Exception("existed user!");
			People.add(person);
			System.out.printf("%s %s is added into MiniNet\n", 
					person.getType(), person.getName());
			
		}
		catch(Exception e) {System.out.println(person.getType() + " "
				+ person.getName() + " cannot be added to MiniNet because \n"
				+ e.getMessage());
		}
	}
	
	
	public void loadUser(Person person) {
		boolean existed = false;
		try {
			for(Person p:People) {
				if (p.getName() == person.getName())
					existed = true;
			}
			//if content is duplicated, throw an exception and print error message;
			if(existed) throw new Exception("existed user!");
			register.add(person);
			System.out.printf("%s has loaded into MiniNet and wait to be validated\n", person.getName());
		}
		catch(Exception e) {System.out.println(person.getType() + " "
				+ person.getName() + " cannot be added to MiniNet because \n"
				+ e.getMessage());
		}
	}
	
	
	public void addPersonByString(String[] str) {
		Person p;
		String[] info = str;
		if (Integer.valueOf(info[4]) > 16) {
            p = new Adult(info[0], info[1], info[2], info[3].charAt(0), Integer.parseInt(info[4]), info[5]);
         }
     else if (Integer.parseInt(info[4]) <= 2) {
            p = new YoungChild(info[0], info[1], info[2], info[3].charAt(0), Integer.parseInt(info[4]), info[5]);
         }
     else {
            p = new Child(info[0], info[1], info[2], info[3].charAt(0), Integer.parseInt(info[4]), info[5]);
         }
		loadUser(p);
      }
	
	
	public void validateRegister() {
		for(Person p: register) {
			addUser(p);
		}
		register = new ArrayList<>();
	}
	
	
	public Stage getPrimaryStage() {
	      return primaryStage;
	   }
	
	
	public void deleteUser(Person person) {
		person.deleteSelf();
		People.remove(person);
	}
	
}//end class