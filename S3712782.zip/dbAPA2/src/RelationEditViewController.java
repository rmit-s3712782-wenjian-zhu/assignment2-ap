import java.util.InputMismatchException;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class RelationEditViewController {
	MiniNet model;
	private Stage subStage;
	private ObservableList<String> People = FXCollections.observableArrayList ();
	private Person p1;
	private Person p2;
	
	@FXML
	private TextField relationShip;
	@FXML
	private ChoiceBox<String> relationBox;
	@FXML
	private ListView<String> showProfileList;
	@FXML
	private ListView<String> showProfileList2;
	
	public RelationEditViewController() {}
	    
	@FXML
	private void initialize() {
		relationBox.getItems().addAll("classmates","colleagues","parent","friend","couple");
		showProfileList.getSelectionModel().selectedItemProperty().addListener((observable, oldValue, newValue) -> {
    		if(newValue != null && !(newValue.equals(oldValue))) {
    			p1 = model.selectPersonByName(newValue);
    			update();
    		}
         });
		showProfileList2.getSelectionModel().selectedItemProperty().addListener((observable, oldValue, newValue) -> {
			 if(newValue != null && !(newValue.equals(oldValue))) {
				 p2 = model.selectPersonByName(newValue);
				 update();}
		 });
	 }
	 
	 public void setStage(Stage stage) {
		 this.subStage = stage;
	 }
	    
	 public void setModel(MiniNet model) {
		 this.model = model;
		 update();
	 }
	 
	 public void update() {
		 People = FXCollections.observableArrayList ();
		 for(Person p: model.getPeople()) {
			 People.add(p.getName());
			 }
	    showProfileList.setItems(People); 
	    showProfileList2.setItems(People);
	    if(p1 != null && p2 != null) {
	    	relationShip.setText(p1.checkRelation(p2));
	    }
	 }
	 
	 @FXML
	 private void handleReturn() {
	     subStage.close();
	 }
	 
	 @FXML
	 private void handleAdd() throws Exception{
		String choice = relationBox.getSelectionModel().getSelectedItem();
		if (p1 != null & p2 != null) {
		try {
		if(choice == "classmates") {
			if(p1 instanceof Classmate && p2 instanceof Classmate) {
				((Classmate) p1).makeClassmate(p2);
				} throw new NotToBeClassMatesException("One memeber ");
		} else if (choice == "couple") {
			if(p1 instanceof Adult && p2 instanceof Adult) {
				((Adult) p1).marryTo(p2);}
		} else if (choice == "colleagues") {
			if(p1 instanceof Adult && p2 instanceof Adult) {
				((Adult) p1).makeColleague((Adult) p2);}
			else throw new NotToBeColleaguesException("One member");
		} else if (choice == "parent") {
			if(p1.getAge() < p2.getAge()) {
				if(p1 instanceof Dependent && p2 instanceof Adult) {
					((Adult)p2).makeParent((Dependent) p1);}
			} else if (p1.getAge() > p2.getAge()) {
				if(p2 instanceof Dependent && p1 instanceof Adult) {
					((Adult)p1).makeParent((Dependent) p2);}}
		} else if (choice == "friend") {
			p1.makeFriend(p2);
		}	else throw new InputMismatchException();}
		catch(InputMismatchException e){
			System.out.println("Invalid input, try again...");
		}
		catch(Exception e) {
			System.out.println("Error, try again");
			System.out.println(e.getMessage());
		}
		}
		else System.out.println("Select two users first");
	 }
	 
	 
	 @FXML
	 private void handleRemove() {
	     p1.delete(p2);
	     p2.delete(p1);
	 }

}
