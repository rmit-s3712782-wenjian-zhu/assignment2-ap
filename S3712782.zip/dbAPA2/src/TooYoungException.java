@SuppressWarnings("serial")
public class TooYoungException extends Exception{

	TooYoungException() {
		super("Young child cannot make friends.");
	}

}
