import java.util.ArrayList;

public class Child extends Dependent implements Classmate{
	
	private ArrayList<Person> classmates = new ArrayList<>();
	
	/**
	 * @param name 
	 * @param age
	 * @param status
	 * @param photo
	 * @param gender
	 * @param state
	 * @throws NoSuchAgeException
	 */
	public Child(String name, String photo, String status, char gender, int age, String state) {
	    super(name, photo, status, gender, age, state);
	}

	
	public String getParents() {
		return getParent1().getName() + " and " + getParent2().getName();
	}
	
	//Getter and setter
	public String getType() {
		return "Child";
	}

	
	@Override
	public void makeFriend(Person p) {
		try {
			if (p instanceof YoungChild) throw new TooYoungException();
			else if (p instanceof Adult) throw new NotToBeFriendsException();
			else {
				if (Math.abs(getAge() - p.getAge()) > 3) throw new NotToBeFriendsException();
				else if(sameFamily((Dependent) p)) System.out.println("Dependents from same family cannot be friends");
				else {
					addFriend(p);
					p.addFriend(this);
				}
			}
			}
		catch(TooYoungException e) {
			System.out.println(e.getMessage());
			System.out.println(getName() + " and " + p.getName() + " cannot be friends. ");
			}
		catch(NotToBeFriendsException e) {
			System.out.println(e.getMessage());
			System.out.println(getName() + " and " + p.getName() + " cannot be friends. ");
			}
	}


	public void addClassmate(Person p) {
		classmates.add(p);
		System.out.printf("%s is now classmate with %s\n",getName(),p.getName());
	}


	
	
	public ArrayList<Person> getClassmates() {
		return classmates;
	}


	@Override
	public void makeClassmate(Person p) {
		try {
			if(p instanceof YoungChild) throw new NotToBeClassMatesException(p.getName());
			else {
				addClassmate(p);
				if (p instanceof Adult) {
				((Adult) p).addClassmate(this);
				}
				else ((Child) p).addClassmate(this);
			}
		}
		catch (Exception e) {
			System.out.println(e);
			System.out.println(getName() + " and " + p.getName() + " cannot be classmates");
		}
	}


	/**
	 * Remove classmate relation if there is a classmate with same name
	 * @param p
	 */
	public void removeClassmate(Person p){
		for(Person p2: getClassmates()) {
			if(p2.getName() == p.getName()) {
				getClassmates().remove(p2);
				System.out.printf("%s is no longer classmate with %s\n",getName(),p.getName());
			}
		}//end for
	}//end method

	
	public boolean checkClassmate(Dependent p2) {
		for(Person p: getClassmates()) {
			if (p.getName().equals(p2.getName())) {
					System.out.println(getName() + " and " + p2.getName() + " are classmates");
				return true;
			}
		}
		return false;
	}
	
	
	@Override
	public String checkRelation(Person p) {
		if(p instanceof Adult) {
			return p.checkRelation(this);
		}
		else {
		String s = "";
		if(p instanceof Dependent) {
			if(checkClassmate((Dependent) p)) s += "classmate, ";
			if(checkFriendship(p)) s += "friend, ";
		}
		else if(checkFriendship(p)) s += "sibling, ";
		if (s.equals("")) {
			s = "No direct relation.";
		}
		else {
			s = s.substring(0, s.length() - 2);
		}
		if(this.getName().equals(p.getName())) s = "Self";
		return s;
		}
	}
	
	@Override
	public void delete(Person p) {
		if(p instanceof Dependent) {
			removeClassmate(p);
			deleteFriend(p);}
	}


	@Override
	public void deleteSelf() {
		for(Person p: this.getFriends()) {
			p.delete(this);
		}
		for(Person p: this.getClassmates()) {
			p.delete(this);
		}
		getParent1().removeChild(this);
		getParent2().removeChild(this);
		System.out.println(this.getName() + " has succesfully been deleted from MiniNet");
	}
	
}