import java.io.IOException;


import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.stage.Stage;

public class mainViewController {
	
	private ObservableList<String> People = FXCollections.observableArrayList ();
	private ObservableList<String> Friends = FXCollections.observableArrayList ();
	Person p = null;
	private MiniNet model;
	private AddPersonViewController subController;
	private RelationEditViewController subController2;
	
	@FXML
	private ListView<String> showFriendship;
	@FXML
	private ListView<String> showProfileList;
    @FXML
    private Label parentLabel;
	@FXML
    private Label nameLabel;
    @FXML
    private Label genderLabel;
    @FXML
    private Label ageLabel;
    @FXML
    private Label stateLabel;
    @FXML
    private Label statusLabel;
    @FXML
    private Label photoLabel;
    @FXML
    private Label childrenOrParentsLabel;
    @FXML
    private Label childrenorParents;
    
    public mainViewController() {}
    
    @FXML
    private void initialize() {
    	showProfile(null);
    	showProfileList.getSelectionModel().selectedItemProperty().addListener((observable, oldValue, newValue) -> {
    		if(newValue != null && !(newValue.equals(oldValue))) {
    			p = model.selectPersonByName(newValue);
    			showProfile(p);
    			update();
    		}
         });
		
    }
    
    
    public void showProfile(Person p) {
        if (p != null) {
           nameLabel.setText(p.getName());
           genderLabel.setText(Character.toString(p.getGender()));
           statusLabel.setText(p.getStatus());
           ageLabel.setText(Integer.toString(p.getAge()));
           stateLabel.setText(p.getState());
           if (p.getPhoto()!=null && !p.getPhoto().isEmpty()) {
        	   photoLabel.setText("Photo");
           }
           else photoLabel.setText("- empty -");
           if(p instanceof Adult) {
        	   String children = null;
        	   childrenorParents.setText("Children:");
        	   children = "";
        	   if(((Adult) p).getChildren().size() > 0) {
        		   for (Person p2: ((Adult) p).getChildren()) {
        			   children += p2.getName() + ", ";
        		   			}
        		   	children = children.substring(0, children.length() - 2);
        		   	
        	   			}
        	   childrenOrParentsLabel.setText(children);
           			}
           else {
        	   childrenorParents.setText("Parents:");
        	   childrenOrParentsLabel.setText(((Dependent)p).getParent1().getName() 
        			   + " and " + ((Dependent)p).getParent2().getName());
        	   			}
        } else {
           // Person is null, remove all the text.
           nameLabel.setText("");
           genderLabel.setText("");
           ageLabel.setText("");
           statusLabel.setText("");
           stateLabel.setText("");
           photoLabel.setText("");
           childrenOrParentsLabel.setText("");
        }
     }
    
    @FXML
    public void addPerson() {
    	displayAddPersonInterface();
    }
    
    @FXML
    public void editPerson() {
    	displayEditPersonInterface();
    }
    
    @FXML
    public void exit() {
    	System.out.println("Exiting...");
    	System.exit(0);
    }
    
    public void displayAddPersonInterface() {
		try {
			FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("addPerson.fxml"));
	        Stage subStage = new Stage();
	        subStage.setTitle("Add a person");
	        Scene subScene = new Scene(fxmlLoader.load());
	        subStage.setScene(subScene);
	        subStage.setResizable(false);
	        subStage.show();
	        subController = fxmlLoader.getController();
	        subController.setModel(this.getModel());
	        subController.setStage(subStage);
	        } catch (IOException e) {
	        	e.printStackTrace();
	        	}
		}
    
    public void displayEditPersonInterface() {
		try {
			FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("relationEdit.fxml"));
	        Stage subStage = new Stage();
	        subStage.setTitle("Edit Relation");
	        Scene subScene = new Scene(fxmlLoader.load());
	        subStage.setScene(subScene);
	        subStage.setResizable(false);
	        subStage.show();
	        subController2 = fxmlLoader.getController();
	        subController2.setModel(this.getModel());
	        subController2.setStage(subStage);
	        } catch (IOException e) {
	        	e.printStackTrace();
	        	}
		}
   
    @FXML
    public void handleDelete() {
    	if (p != null) {
    		model.deleteUser(p);
    	} else {
    		System.out.println("You have to select a person in order to perform this action");
    	}
    }
    
    public void setModel(MiniNet model) {
    	this.model = model;
    	update();
    }
    
    public MiniNet getModel() {
    	update();
    	return model;
    }
    
    public void update() {
    	People = FXCollections.observableArrayList ();
    	Friends = FXCollections.observableArrayList ();
    	for(Person p1: model.getPeople()) {
    		People.add(p1.getName());
    	}
    	if (p != null) {
    	for(Person p2: p.getFriends()) {
    		Friends.add(p2.getName());
    	}
    	}
    	showFriendship.setItems(Friends);
    	showProfileList.setItems(People); 
    }
}
