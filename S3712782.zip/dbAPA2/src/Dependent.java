import java.util.ArrayList;

/**
 * Dependent is a abstract subclass of person which is the super
 * class of Child and YoungChild. It holds all the person in MiniNet
 * who are 16 or younger.
 */
public abstract class Dependent extends Person{
	
	private Adult parent1;
	private Adult parent2;
	private ArrayList<Person> classmates = new ArrayList<>();
	
	
	public Dependent(String name, String photo, String status, char gender, int age, String state) {
	    super(name, photo, status, gender, age, state);
	    }

	//Getter and setters.
	public Adult getParent1() {
		return parent1;
	}

	public Adult getParent2() {
		return parent2;
	}
	
	public void setParent1(Adult a) {
		parent1 = a;
	}
	
	public void setParent2(Adult a) {
		parent2 = a;
	}
	
	public boolean sameFamily(Dependent d) {
		if (parent1 == d.getParent1() || parent1 == d.getParent2())
			return true;
		return false;
	}
	
	public void marryTo(Person p) {
		try {throw new NotToBeCoupledException(this.getName());}
		catch(NotToBeCoupledException e) {
			System.out.println(e.getMessage());
		}
	}
	
	public void makeParent(Person p) {
		try {
			if (p instanceof Dependent) 
				throw new NoParentException("Dependent requires to have two parents");
			else if (((Adult) p).getPartner() == null) 
				throw new NoParentException("Dependent requires to have two parents");
			else {
				if (getParent1() == null) {
					setParent1((Adult) p);
					System.out.println(this.getName() + " added " + p.getName() + " as parent one");
				}
				else if (getParent2() == null) {
					setParent2((Adult) p);
					System.out.println(this.getName() + " added " + p.getName() + " as parent two");
				}
				else throw new NoParentException("Dependent cannot have three parents");
			}
		}
		catch(Exception e) {
			System.out.println(e.getMessage());
			System.out.println(getName() + " cannot add " + p.getName() + " as parent ");
			}
	}
	
	public abstract String checkRelation(Person p);
	public abstract void delete(Person p);
}
