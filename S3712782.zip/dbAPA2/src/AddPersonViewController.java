import java.util.InputMismatchException;
import javafx.fxml.FXML;
import javafx.scene.control.TextField;
import javafx.scene.control.ChoiceBox;
import javafx.stage.Stage;
/**
 * Controller for view of addPerson
 * @author Wenjian Zhu
 *
 */
public class AddPersonViewController {
	MiniNet model;
	private Stage Stage;
	
	@FXML
	private TextField statusText;
	@FXML
	private TextField ageText;
	@FXML
	private TextField nameText;
	@FXML
	private ChoiceBox<String> genderBox;
	@FXML
	private ChoiceBox<String> stateBox;
	@FXML
	private ChoiceBox<String> photoBox;
	
	@FXML
	private void initialize() {
		photoBox.getItems().addAll("1.jpg","2.jpg","3.jpg");
		genderBox.getItems().addAll("M", "F");
	    stateBox.getItems().addAll("ACT", "NSW", "NT", "QLD", "SA", "TAS", "VIC", "WA");
	}
	
	
	@FXML
    private void handleSubmit(){
		try {
          if (Integer.parseInt(ageText.getText()) > 150 || Integer.parseInt(ageText.getText()) < 0) {
             throw new NoSuchAgeException(nameText + " cannot be added.", Integer.parseInt(ageText.getText()));
          }
          String[] info = new String[6];
          info[0] = nameText.getText();
          info[1] = (String) photoBox.getSelectionModel().getSelectedItem();
          info[2] = statusText.getText();
          info[3] = (String) genderBox.getSelectionModel().getSelectedItem();
          info[4] = ageText.getText();
          info[5] = (String) stateBox.getSelectionModel().getSelectedItem();
          if ( info[3] == null || info[4] == null) throw new Exception("Requires name, age and gender...");
          model.addPersonByString(info);
          model.validateRegister();
          Stage.close();
          // throws exceptions
       } catch (NoSuchAgeException e) {
       	   System.out.println(e.getMessage());
       } catch (InputMismatchException e) {
    	   System.out.println("Invalid input.");
       } catch (Exception e) {
    	   e.printStackTrace();
    	   System.out.println("Requires correct information...");
       }
    }
    
    @FXML
    public void handleReturn() {
    	Stage.close();
    }
    
    public void setStage(Stage stage) {
    	this.Stage = stage;
    }
    
    public void setModel(MiniNet model) {
        this.model = model;
     }
}
