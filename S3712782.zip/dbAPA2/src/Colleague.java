
public interface Colleague {
	public void makeColleague(Person person) throws Exception;
	public void removeColleague(Person person) throws Exception;
}
