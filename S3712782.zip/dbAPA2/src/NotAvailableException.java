
public class NotAvailableException  extends Exception{
	
	NotAvailableException(String errmsg) {
		super(errmsg);
	}

}
