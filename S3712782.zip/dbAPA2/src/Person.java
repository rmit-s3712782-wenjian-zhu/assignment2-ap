import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
/**
 * The Person class provides ...
 */
public abstract class Person {

	private String name;
	private int age;
	private String photo;
	private String status;
	private char gender;
	private String state;
	private ArrayList<Person> friends = new ArrayList<>();
	

	/**
	 * @param name 
	 * @param age
	 * @param status
	 * @param photo
	 * @param gender
	 * @param state
	 * @throws NoSuchAgeException
	 */
	public Person(String name, String photo, String status, char gender, int age, String state) {
		this.name = name;
		this.status = status;
		setAge(age);
		this.gender = gender;
		this.state = state;
		this.photo = photo;
	}
	
	/**
	 * 
	 * @param p Person which will be added to current person's friend list.
	 */
	public void addFriend(Person p) {
		this.friends.add(p);
		System.out.printf("%s is now friend with %s\n",getName(),p.getName());
	}
	
	public void deleteFriend(Person p) {
		this.friends.remove(p);
		System.out.printf("%s is no longer friend with %s\n",getName(),p.getName());
	}


	//Getters:
	public String getName(){return name;}
	public int getAge(){return age;}
	public String getPhoto(){return photo;}
	public String getStatus(){return status;}
	public char getGender() {return gender;}
	public String getState() {return state;}
	public List<Person> getFriends(){return friends;}
	//Setters:
	public void setName(String name) {this.name = name;}
	public void setPhoto(String photo) {this.photo = photo;}
	public void setStatus(String str) {this.status = str;}
	public void setGender(char gender) {this.gender = gender;}
	public void setState(String state) {this.state = state;}

	
	
	
	public void setAge(int age) {
		try {
			if( age < 0 || age > 150) {
				String err = getType() + " " + getName() + " cannot be added.";
				throw new NoSuchAgeException( err , age);
			}
				this.age = age;
				}
		catch(NoSuchAgeException e) {
			System.out.println(e.getMessage());
		}
	}
	
	


	/**
	 * This method supports the functionality of case 8 for MainMenu() in driver class.
	 * It checks whether user2 is in Person's friendliest.
	 * @param user2
	 */
	public boolean checkFriendship(Person user2) {
		if (user2 == null) {
			System.out.println("Please select another person.");
			return false;}//end if
		else if (getName() == user2.getName()) {
			System.out.println("Please choose another person other than yourself.");
			return false;}//end else if
		else {
			for(Person p: getFriends()) {
				if (user2.getName() == p.getName()) {
					System.out.println(getName() + " and " + user2.getName() + " are friends.");
					return true;
				}
			}//end for
			return false;
		}//end else
	}//end method
	
	/**
	 * This method return selected person's display profile.
	 * It supports functionality of case 4.
	 * @param user
	 */
	public void displayProfile() {
		System.out.println("\n======================================");
		System.out.println("Name: " + name);
		System.out.println("Age: " + age);
		if (getPhoto() != null)
			System.out.println("Photo: " + photo);
		else System.out.println("Photo: no image");
		if (getStatus() != null)
			System.out.println("Status: " + status);
		else System.out.println("Status: -empty-");
		if(this instanceof Dependent) {
				System.out.println("Parents:");
				System.out.println(((Dependent) this).getParent1().getName() + " and " 
										+ ((Dependent) this).getParent2().getName());}
			else if(this instanceof Adult && ((Adult) this).getPartner() != null) {
				System.out.println("Married to: " + ((Adult) this).getPartner().getName());
				}
		System.out.println("Friend with:");
			for(Person p: getFriends()) {
				System.out.println(p.getName());}
	}
	
	public void delete(Person p) {
		deleteFriend(p);
	}
	
	/**
	 * This method supports the functionality of case 7 for MainMenu() in driver class.
	 * It checks connect two person as friends.
	 * @param user2
	 */
	public abstract void makeFriend(Person p);
	public abstract void deleteSelf();
	public abstract String getType();
	public abstract String checkRelation(Person p);
	
	
}


